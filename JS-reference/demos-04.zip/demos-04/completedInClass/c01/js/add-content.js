var today = new Date();
var hourNow = today.getHours();
var greeting;

if (hourNow > 18) {
    greeting = 'Good evening!';
} else if (hourNow > 12) {
    greeting = 'Good afternoon!';
} else if (hourNow > 0) {
    greeting = 'Good morning!';
} else {
    greeting = 'Welcome!';
}

//document.write('<h3>' + greeting + '</h3>');

var newEl = document.createElement('h3'); //create an h3 (empty)
newEl.appendChild(document.createTextNode(greeting)); //inserts text into our h3
var ref = document.querySelector('h1'); //selecting h1 as a reference

function insertAfter(el, referenceNode) {
	//find the referenceNode's parent. insert our el before referenceNode's next sibling
    referenceNode.parentNode.insertBefore(el, referenceNode.nextSibling);
}


insertAfter(newEl, ref);


