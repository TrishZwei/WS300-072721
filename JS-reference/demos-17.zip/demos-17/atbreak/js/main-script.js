//start with JS detection
$('html').removeClass('no-js').addClass('js');

//vanilla alternative: 
//document.querySelector('html').classList = 'js';

const nav = $('.main-nav'); //stores our navigation element
let topOfNav = nav.position().top;
let heightOfNav = nav.height();
const theBod = $('body'); //stores the body element

//stickyNav function

function fixNav(){
	if($(window).scrollTop() >= topOfNav){
		theBod.addClass('fixed-nav');
		//takes nav out of flow since it becomes fixed
	}else{
		theBod.removeClass('fixed-nav');
		//puts the nav back into the flow since it is no longer fixed
	}


}

//listener for sticky nav

$(window).on('scroll', fixNav);


//when clicking on nav lis.....
let clicked = 0;
//checks for if the nav is still in the flow
$('.main-nav li a').on('click', function(e){
console.log('test');

//e captures the event object
clicked++; //adds 1 to our clicked
e.preventDefault();


	if(this.hash !== ''){
		 //prevents a tag from jumping
		//store the hash
		let hash = this.hash; //gets the value of the hash that was clicked

		let winTop = $(window).scrollTop();
		//scrollTop tells us where the window is before scrolling to the item clicked

		let hashPageY = $(hash).offset().top; 
		//finds where the anchor tag that was clicked - is on the page.
		let menuOffset = $('.main-nav').height(); //gets height of nav element

		if(winTop < hashPageY){
			//scrolling down
			if(hashPageY > topOfNav){
				//we should see the sticky nav
				hashPageY -= menuOffset;
				//remove menu value

				if(clicked == 1 && $('body.fixed-nav').length == 0){
				hashPageY -= menuOffset;
				//adding the offset again when it comes from the top of the page from the menu-- that menu that got taken out of the flow and affected the position of all the elemenents that followed after	
				}

			}else{
				console.log('we should see the nav go away');
			}

		}else{
			//scrolling up

			if(hashPageY > topOfNav){
				//sticky nav should be present
				hashPageY -= menuOffset;
			}else{
				clicked = 0
			}

		} //end if going up or down

		//jq animate method to add smooth page scroll

		let bodAnimate = 0; //has animation been activated?

		$('html, body').animate({
			scrollTop:(hashPageY)
		}, 800, function(){
			//this is getting called twice due to being put on two different elements
			if(bodAnimate == 0){
				//run animation
				bodAnimate++;
				//do history api stuff next
			}

		})

	}//end if hash != '' 

}) //end of click on lis


